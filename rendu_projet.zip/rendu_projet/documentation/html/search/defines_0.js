var searchData=
[
  ['debutx_140',['DEBUTX',['../affiche_8h.html#aa8d177041ed63e23e77e431f9de60d3a',1,'affiche.h']]],
  ['debuty_141',['DEBUTY',['../affiche_8h.html#a0c8a6c78f96b789d1478544dff37f770',1,'affiche.h']]]
];
