var indexSectionsWithContent =
{
  0: "acdefgilmnortuv",
  1: "cdegnot",
  2: "acfmnot",
  3: "acfilmnortu",
  4: "acdimotv",
  5: "dt",
  6: "dt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Énumérations",
  6: "Macros"
};

