/**
 * coordonne.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : ??
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet de gere les coordonnée
 */
#include "../header/coordonne.h"

