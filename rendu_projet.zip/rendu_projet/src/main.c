/**
 * main.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : ??
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * main du projet
 *
 */
#include "../header/moteur.h"
#include "../header/config_stdin.h"

int main(int argc, char **argv){

    utilise_argv(argc, argv);
    return 0;
}
