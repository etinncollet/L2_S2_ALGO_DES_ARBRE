/**
 * affiche.h
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : 16/05/2021
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet de gere l'affichage
 */
#include "../header/affiche.h"


int mini(int un, int deux){
    if(un <= deux)
        return un;
    return deux;
}


void affiche_usage(){
    system("clear");
    fprintf(stderr, "\n\t\t--- tempsreel ---\n\n\n\tSYNOPSIS :\n\nUsage 1: ./tempreels --test=<int>\n");
    fprintf(stderr, "\tLance le programme avec un niveau exemple.\n\t <int> comprie entre 0 et 1\n");
    fprintf(stderr, "\nUsage 2: ./tempreels --usage\n");
    fprintf(stderr, "\taffiche les diferents argumuments possible du programme et leurs fonctionnement\n");
    fprintf(stderr, "\nUsage 3: ./tempreels --f nom_fichier\n");
    fprintf(stderr, "\tOuvre le niveau du fichier dans le terminal\n\n");
    fprintf(stderr, "\n\tDESCRIPTION :\n\n\tCeci est un petit jeux");
    fprintf(stderr, "\nL'objectif est d'emener notre personnage a l'arriver");
    fprintf(stderr, "\nPour cela nous utilisons les touche :'q', 's', 'd', 'z' pour nous deplacer\n\n");
    fprintf(stderr, "\n23/04/2021\tEtienne Collet / Lyna Benaibouche\t V : 1.2\n\n");
}


void ouvre_fenettre(unsigned int *longueur, unsigned int *largeur){
    assert(longueur != NULL);
    assert(largeur != NULL);
    MLV_get_desktop_size(longueur, largeur);
    (*largeur) -= 60;
    MLV_create_window_with_default_font( "tempsreel", NULL, (*longueur), (*largeur), "./ttf/run.ttf", 40);
    MLV_clear_window(MLV_COLOR_WHITE);
    MLV_update_window();
}


void affiche_menu(char nom[][TMOTS], int nombre){
    int i, ptx[4], pty[4], txt_lo, txt_la;
    for(i = 0; i < nombre; i++){
        MLV_get_size_of_text(nom[i], &txt_lo, &txt_la);
        MLV_draw_filled_rectangle(i * 250, 0, 250, 75, MLV_COLOR_GREY);
        MLV_draw_rectangle(i * 250, 0, 250, 75, MLV_COLOR_BLACK);
        MLV_draw_text((i * 250) + 125 - (txt_lo / 2), 20, nom[i], MLV_COLOR_BLACK);
    }
    ptx[0] = i * 250;
    ptx[1] = i * 250;
    ptx[2] = (i * 250) + 100;
    ptx[3] = (i * 250) + 150;

    pty[0] = 0;
    pty[1] = 74;
    pty[2] = 74;
    pty[3] = 0;
    MLV_draw_line((i * 250) + 160, 0, (i * 250) + 110, 74, MLV_COLOR_BLACK);
    MLV_draw_filled_polygon(ptx, pty, 4, MLV_COLOR_GREY);
    MLV_draw_polygon(ptx, pty, 4, MLV_COLOR_BLACK);
    MLV_update_window();
}


/*


*/
void affiche_graph_niv(unsigned int longueur, unsigned int largeur, Niveau niv, int grille){
    unsigned int max, i, j;
    MLV_Image *lol1, *lol2, *lol3, *lol4, *lol5, *lol6, *lol7, *lol8;
    max = mini((largeur - 150) / niv.taille.y, (longueur - 200) / niv.taille.x);

    #ifndef CONST
        lol1 = MLV_load_image("./image/bas_sf.png");
        MLV_resize_image(lol1, max, max);
        #define IMG_B lol1

        lol2 = MLV_load_image("./image/haut_sf.png");
        MLV_resize_image(lol2, max, max);
        #define IMG_H lol2

        lol3 = MLV_load_image("./image/droite_sf.png");
        MLV_resize_image(lol3, max, max);
        #define IMG_D lol3

        lol4 = MLV_load_image("./image/gauche_sf.png");
        MLV_resize_image(lol4, max, max);
        #define IMG_G lol4

        lol5 = MLV_load_image("./image/mur_sf.png");
        MLV_resize_image(lol5, max, max);
        #define IMG_MUR lol5

        lol6 =  MLV_load_image("./image/perso_sf.png");
        MLV_resize_image(lol6, max, max);
        #define IMG_PERS lol6

        lol7 = MLV_load_image("./image/arriver.png");
        MLV_resize_image(lol7, max, max);
        #define IMG_DEST lol7

        lol8 = MLV_load_image("./image/canon_sf.png");
        MLV_resize_image(lol8, max, max);
        #define IMG_LANC lol8

        #define CONST 1
    #endif

    for(i = 0; i < niv.taille.y; i++){
        for(j = 0; j < niv.taille.x; j++){
            MLV_draw_filled_rectangle(DEBUTX + (j * max), DEBUTY + ((i) * max), max, max, MLV_COLOR_GREY);
            if(grille){
                MLV_draw_rectangle(DEBUTX + (j * max), DEBUTY + ((i) * max), max, max, MLV_COLOR_BLACK);
            }
            if(niv.objets[j][niv.taille.y - i - 1].type == PROJECTILE){
                if(((Deplacement*)niv.objets[j][niv.taille.y - i - 1].donnee_suppl) -> direction == HAUT){
                    MLV_draw_image(IMG_H, DEBUTX + (j * max), DEBUTY + ((i) * max));
                }else if(((Deplacement*)niv.objets[j][niv.taille.y - i - 1].donnee_suppl) -> direction == BAS){
                    MLV_draw_image(IMG_B, DEBUTX + (j * max), DEBUTY + ((i) * max));
                }else if(((Deplacement*)niv.objets[j][niv.taille.y - i - 1].donnee_suppl) -> direction == GAUCHE){
                    MLV_draw_image(IMG_G, DEBUTX + (j * max), DEBUTY + ((i) * max));
                }else if(((Deplacement*)niv.objets[j][niv.taille.y - i - 1].donnee_suppl) -> direction == DROITE){
                    MLV_draw_image(IMG_D, DEBUTX + (j * max), DEBUTY + ((i) * max));
                }
                /*MLV_draw_filled_rectangle(DEBUTX + (j * max), DEBUTY + ((i) * max), max, max, MLV_COLOR_RED);*/
            }else if(niv.objets[j][niv.taille.y - i - 1].type == LANCEUR){
                MLV_draw_image(IMG_LANC, DEBUTX + (j * max), DEBUTY + ((i) * max));
            }else if(niv.objets[j][niv.taille.y - i - 1].type == PERSONNAGE){
                MLV_draw_image(IMG_PERS, DEBUTX + (j * max), DEBUTY + ((i) * max));
            }else if(niv.objets[j][niv.taille.y - i - 1].type == DESTINATION){
                MLV_draw_image(IMG_DEST, DEBUTX + (j * max), DEBUTY + ((i) * max));
                /*MLV_draw_filled_rectangle(DEBUTX + (j * max), DEBUTY + ((i) * max), max, max, MLV_COLOR_GREEN);*/
            }else if(niv.objets[j][niv.taille.y - i - 1].type == MUR){
                MLV_draw_image(IMG_MUR, DEBUTX + (j * max), DEBUTY + (i * max));
            }
        }
    }
    MLV_draw_rectangle(DEBUTX - 10, DEBUTY - 10, (j * max) + 20, (i * max) + 20, MLV_COLOR_BLACK);
    MLV_update_window();
}


void affiche_bare_latterale(unsigned int longueur, unsigned int largeur, unsigned int choix){
    unsigned int cas = (largeur - 150) / 6, i, max = 3 * (cas / 5);
    int ptx[4], pty[4], txt_long, txt_haut;
    MLV_Image *liste[5];
    char nom[5][15] = {"VIDE", "PERSONNAGE", "DESTINATION", "MUR", "LANCEUR"};
    MLV_Font* font = MLV_load_font( "./ttf/run.ttf" , 17);

    assert(choix < 6);

    liste[1] = MLV_load_image("./image/perso_sf.png");
    MLV_resize_image(liste[1], max, max);

    liste[4] = MLV_load_image("./image/canon_sf.png");
    MLV_resize_image(liste[4], max, max);

    liste[3] = MLV_load_image("./image/mur_sf.png");
    MLV_resize_image(liste[3], max, max);

    liste[2] = MLV_load_image("./image/arriver.png");
    MLV_resize_image(liste[2], max, max);

    for(i = 0; i < 5; i++){
        if(i == choix){
            MLV_draw_filled_rectangle(longueur - cas, largeur - ((i + 1) * cas), cas, cas, MLV_COLOR_GREY50);
            MLV_draw_rectangle(longueur - cas, largeur - ((i + 1) * cas), cas, cas, MLV_COLOR_BLACK);
        }else{
            MLV_draw_filled_rectangle(longueur - cas, largeur - ((i + 1) * cas), cas, cas, MLV_COLOR_GREY);
            MLV_draw_rectangle(longueur - cas, largeur - ((i + 1) * cas), cas, cas, MLV_COLOR_BLACK);
        }
        MLV_get_size_of_text_with_font(nom[i], &txt_long, &txt_haut, font);
        MLV_draw_text_with_font(longueur - (cas/2) - (txt_long/2), largeur - ((i + 1) * cas) + 5, nom[i], font, MLV_COLOR_BLACK);
        MLV_draw_filled_rectangle((longueur - cas) + (cas / 5), largeur - ((i + 1) * cas) + (cas / 5) + 3, 3 * (cas / 5), 3 * (cas / 5), MLV_COLOR_GREY);
        if(i != 0){
            MLV_draw_image(liste[i], (longueur - cas) + (cas / 5), largeur - ((i + 1) * cas) + (cas / 5) + 3);
        }

        MLV_draw_rectangle((longueur - cas) + (cas / 5), largeur - ((i + 1) * cas) + (cas / 5) + 3, 3 * (cas / 5), 3 * (cas / 5), MLV_COLOR_BLACK);
    }
    ptx[0] = longueur - cas;
    ptx[1] = longueur - cas;
    ptx[2] = longueur - 1;
    ptx[3] = longueur - 1 ;

    pty[0] = largeur - (i * cas);
    pty[1] = largeur - (i * cas) - 50;
    pty[2] = largeur - (i * cas) - 100;
    pty[3] = largeur - (i * cas);
    MLV_draw_filled_polygon(ptx, pty, 4, MLV_COLOR_GREY);
    MLV_draw_polygon(ptx, pty, 4, MLV_COLOR_BLACK);
    MLV_update_window();
    MLV_free_font(font);
    MLV_free_image(liste[1]);
    MLV_free_image(liste[2]);
    MLV_free_image(liste[3]);
    MLV_free_image(liste[4]);
}


void affiche_choix_taille(unsigned int longueur, unsigned int largeur, int choix){
    int taillex = (longueur - 200) / 2, tailley = (largeur - 200);
    int lon, lar;

    MLV_draw_filled_rectangle(100, 100, taillex, tailley, MLV_COLOR_GREY);
    MLV_draw_rectangle(100, 100, taillex, tailley, MLV_COLOR_BLACK);
    if(choix){
        MLV_get_size_of_text("SANS BASE", &lon, &lar);
        MLV_draw_text(100 + (taillex / 2) - (lon / 2), 120, "SANS BASE", MLV_COLOR_BLACK);
    }
}


void affiche_choix_fichier(unsigned int longueur, unsigned int largeur, int choix){
    int taillex = (longueur - 200) / 2, tailley = (largeur - 200);
    int lon, lar;

    MLV_get_size_of_text("AVEC BASE", &lon, &lar);
    MLV_draw_filled_rectangle(100 + taillex, 100, taillex, tailley, MLV_COLOR_GREY);
    MLV_draw_rectangle(100 + taillex, 100, taillex, tailley, MLV_COLOR_BLACK);
    if(choix){
        MLV_draw_text(100 + taillex + (taillex / 2) - (lon / 2), 120, "AVEC BASE", MLV_COLOR_BLACK);
    }
}


void affiche_choix_nombre(int x, int y, int nombre){
    int lon, lar;
    char nbr[5];
    MLV_Font *font = MLV_load_font("./ttf/coolvetica.ttf", 30);
    MLV_draw_filled_rectangle(x, y, 150, 75, MLV_COLOR_WHITE);
    MLV_draw_rectangle(x, y, 150, 75, MLV_COLOR_BLACK);
    MLV_draw_filled_rectangle(x - 75, y, 75, 75, MLV_COLOR_GREY80);
    MLV_draw_filled_rectangle(x + 150, y, 75, 75, MLV_COLOR_GREY80);
    MLV_draw_rectangle(x - 75, y, 75, 75, MLV_COLOR_BLACK);
    MLV_draw_rectangle(x + 150, y, 75, 75, MLV_COLOR_BLACK);

    MLV_get_size_of_text_with_font("<", &lon, &lar, font);
    MLV_draw_text_with_font(x - 37 - (lon / 2), y + 37 - (lar / 2), "<", font, MLV_COLOR_BLACK);

    MLV_get_size_of_text_with_font(">", &lon, &lar, font);
    MLV_draw_text_with_font(x + 187 - (lon / 2), y + 37 - (lar / 2), ">", font, MLV_COLOR_BLACK);

    sprintf(nbr, "%d", nombre);
    MLV_get_size_of_text_with_font(nbr, &lon, &lar, font);
    MLV_draw_text_with_font(x + 75 - (lon / 2), y + 37 - (lar / 2), nbr, font, MLV_COLOR_BLACK);

    MLV_update_window();
    MLV_free_font(font);
}


void affiche_choix_txt(int x, int y, char txt[]){
    int lon, lar;
    MLV_Font *font = MLV_load_font("./ttf/coolvetica.ttf", 30);
    MLV_draw_filled_rectangle(x, y, 300, 75, MLV_COLOR_WHITE);
    MLV_draw_rectangle(x, y, 300, 75, MLV_COLOR_BLACK);
    MLV_draw_filled_rectangle(x - 75, y, 75, 75, MLV_COLOR_GREY80);
    MLV_draw_filled_rectangle(x + 300, y, 75, 75, MLV_COLOR_GREY80);
    MLV_draw_rectangle(x - 75, y, 75, 75, MLV_COLOR_BLACK);
    MLV_draw_rectangle(x + 300, y, 75, 75, MLV_COLOR_BLACK);

    MLV_get_size_of_text_with_font("<", &lon, &lar, font);
    MLV_draw_text_with_font(x - 37 - (lon / 2), y + 37 - (lar / 2), "<", font, MLV_COLOR_BLACK);

    MLV_get_size_of_text_with_font(">", &lon, &lar, font);
    MLV_draw_text_with_font(x + 337 - (lon / 2), y + 37 - (lar / 2), ">", font, MLV_COLOR_BLACK);

    MLV_get_size_of_text_with_font(txt, &lon, &lar, font);
    MLV_draw_text_with_font(x + 150 - (lon / 2), y + 37 - (lar / 2), txt, font, MLV_COLOR_BLACK);

    MLV_update_window();
    MLV_free_font(font);
}


void affiche_niveau_hist(unsigned int longueur, unsigned int largeur, int choix){
    int lon = (longueur - 250) / 2, lar = (largeur - 280) / 4;
    int lon_txt, lar_txt;
    char niv[12];
    int i, j;
    MLV_Font *font = MLV_load_font("./ttf/coolvetica.ttf", 30);
    for(i = 0; i < 2; i++){
        for(j = 0; j < 4; j++){
            MLV_get_size_of_text_with_font("NIVEAU  ", &lon_txt, &lar_txt, font);
            if( (i * 4) + j == choix){
                MLV_draw_filled_rectangle(100 + (i * lon) + (i * 50), 100 + (j * lar) + (j * 20), lon, lar, MLV_COLOR_GREY50);
                MLV_draw_rectangle(100 + (i * lon) + (i * 50), 100 + (j * lar) + (j * 20), lon, lar, MLV_COLOR_RED);
            }else{
                MLV_draw_filled_rectangle(100 + (i * lon) + (i * 50), 100 + (j * lar) + (j * 20), lon, lar, MLV_COLOR_GREY);
                MLV_draw_rectangle(100 + (i * lon) + (i * 50), 100 + (j * lar) + (j * 20), lon, lar, MLV_COLOR_BLACK);
            }
            sprintf(niv, "NIVEAU %d", (i * 4) + j);
            MLV_draw_text_with_font((100 + (i * lon) + (i * 50)) + (lon/2) - (lon_txt/2), 100 + (j * lar) + (j * 20) + (lar/2) - (lar_txt/2), niv, font, MLV_COLOR_BLACK);
        }
    }
    MLV_free_font(font);
    MLV_update_window();
}


void affiche_paneaux_centre(unsigned int longueur, unsigned int largeur, char *texte){
    int x, y;
    MLV_Font* font = MLV_load_font("./ttf/run.ttf", 100);
    MLV_get_size_of_text_with_font(texte, &x, &y, font);
    MLV_draw_filled_rectangle((longueur / 2) - (x / 2) - 50, (largeur / 2) - (y / 2) - 50, x + 100, y + 100, MLV_COLOR_GREY);
    MLV_draw_rectangle((longueur / 2) - (x / 2) - 50, (largeur / 2) - (y / 2) - 50, x + 100, y + 100, MLV_COLOR_BLACK);
    MLV_draw_text_with_font((longueur / 2) - (x / 2), (largeur / 2) - (y / 2), texte, font, MLV_COLOR_LIGHTCORAL);
    MLV_actualise_window();
    MLV_wait_seconds(2);
    MLV_free_font(font);
}


void affiche_exit(unsigned int longueur, unsigned int largeur, int *x, int *y, char *texte){
    MLV_Font* font = MLV_load_font("./ttf/run.ttf", 70);
    MLV_get_size_of_text_with_font(texte, x, y, font);
    MLV_draw_filled_rectangle((longueur / 2) - ((*x) / 2) - 50, (largeur / 2) - ((*y) / 2) - 50, (*x) + 100, (*y) + 250, MLV_COLOR_GREY);
    MLV_draw_rectangle((longueur / 2) - ((*x) / 2) - 50, (largeur / 2) - ((*y) / 2) - 50, (*x) + 100, (*y) + 250, MLV_COLOR_BLACK);
    MLV_draw_text_with_font((longueur / 2) - ((*x) / 2), (largeur / 2) - ((*y) / 2), texte, font, MLV_COLOR_BLACK);

    MLV_get_size_of_text_with_font("OUI", x, y, font);
    MLV_draw_filled_rectangle((longueur / 2) - ((*x) / 2) - 60, (largeur / 2) - ((*y) / 2) + 130, (*x) + 120, (*y) + 40, MLV_COLOR_GREY);
    MLV_draw_rectangle((longueur / 2) - ((*x) / 2) - 60, (largeur / 2) - ((*y) / 2) + 130, (*x) + 120, (*y) + 40, MLV_COLOR_BLACK);
    MLV_draw_text_with_font((longueur / 2) - ((*x) / 2), (largeur / 2) - ((*y) / 2) + 150, "OUI", font, MLV_COLOR_BLACK);
    MLV_actualise_window();
    MLV_free_font(font);
}

