/**
 * fichier.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : 16/05/2021
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet d'ouvrir les different type de fichier
 */
#include "../header/fichier.h"


int taille_chaine(char *chaine){
    int compte;

    assert(chaine != NULL);

    compte = 0;
    while(chaine[compte] != '\0'){
        compte += 1;
    }
    return compte + 1;
}


int fichier_niveaux(char ***nom, int *nombre){
    int taille, bloc = 200, i;
    struct dirent *dir;
    DIR *d = opendir("./niveaux");

    *nombre = 1;
    (*nom) = (char**)calloc(bloc, sizeof(char*));
    if ((*nom) == NULL){
        return 0;
    }
    if (d){
        while ((dir = readdir(d)) != NULL){
            taille = taille_chaine(dir->d_name);
            if(dir->d_name[taille - 5] == '.' && dir->d_name[taille - 4] == 'N' && dir->d_name[taille - 3] == 'I' && dir->d_name[taille - 2] == 'V'){
                (*nom)[(*nombre) - 1 ] = (char*)calloc(taille, sizeof(char));
                if ((*nom)[(*nombre) - 1 ] == NULL){
                    for(i = 0; i < ((*nombre) - 1); i++){
                        free((*nom)[i]);
                    }
                    free((*nom));
                    return 0;
                }
                if((*nombre) % 5 == 5){
                    (*nom) = (char**)realloc(nom, (sizeof(char*) * (((*nombre) / 5)*bloc)) + bloc);
                    if ((*nom) == NULL){
                        for(i = 0; i < ((*nombre) - 1); i++){
                            free((*nom)[i]);
                        }
                        free((*nom));
                        return 0;
                    }
                }
                sprintf((*nom)[(*nombre) - 1 ], "%s", dir->d_name);
                (*nombre) += 1;
            }
        }
        closedir(d);
    }
    (*nombre) -= 1;
    return 1;
}


void free_lst(char **nom_fichier, int nombre){
    int i;
    for(i = 0; i < nombre; i++){
        free(nom_fichier[i]);
    }
    free(nom_fichier);
}


int note_dans_f(Niveau niv, int taille, char *nom){
    FILE *fichier;
    unsigned int i, j, nbr = 0, mdr;
    char tableaux[100];
    Coordonnees *tab;
    assert(nom != NULL);

    tab = (Coordonnees*)calloc(taille, sizeof(Coordonnees));
    if(tab == NULL){
        return 0;
    }
    mdr = taille_chaine(nom);
    nom[mdr - 1] = '.';
    nom[mdr] = 'N';
    nom[mdr + 1] = 'I';
    nom[mdr + 2] = 'V';
    nom[mdr + 3] = '\0';

    sprintf(tableaux, "./niveaux/%s", nom);
    /*fprintf(stderr, "ok %s, %d\n", nom, mdr);*/
    fichier = fopen(tableaux, "r");
    if(fichier == NULL){
        fichier = fopen(tableaux, "w");
        if(fichier == NULL){
            fclose(fichier);
            return 0;
        }
    }else{
        fclose(fichier);
        /*fprintf(stderr, "le fichier existe deja\n");*/
        return 2;
    }
    fprintf(fichier, "%d %d\n", niv.taille.x, niv.taille.y);
    for(i = 0; i < niv.taille.y; i++){
		for(j = 0; j < niv.taille.x; j++ ){
			if(niv.objets[j][niv.taille.y - i - 1].type == LANCEUR ){
			    tab[nbr].x = j;
			    tab[nbr].y = niv.taille.y - i - 1;
			        nbr += 1;
			}
            fprintf(fichier, "%d", niv.objets[j][niv.taille.y - i - 1].type);
        }
        fprintf(fichier, "\n");
    }
    for(i = 0; i < nbr; i++){
        fprintf(fichier, "%d %d %lu %lu\n", tab[i].x, tab[i].y, ((Generation*)(niv.objets[tab[i].x][tab[i].y].donnee_suppl)) -> intervalle, ((Generation*)(niv.objets[tab[i].x][tab[i].y].donnee_suppl)) -> allure_proj);
    }
    fclose(fichier);
    return 1;
}


/**
 * Permet de lire un nombre
 * Si choix est vraix alors x est un unsigned long int
 * Sinon un unsigned int
 */
static int lit_nbr(void *x, int choix, FILE * fichier){
    int nbr;
    long int ret;
    char buf[50], cara;
    nbr = 0;
    do{
        cara = fgetc(fichier);
        buf[nbr] = cara;
        nbr += 1;
    }while(cara != ' ' && cara != '\n' && cara != EOF);
    if(nbr == 0){
        return 0;
    }
    buf[nbr] = '\0';
    ret = atoi(buf);
    if(ret < 0){
        return 0;
    }
    if(choix){
        *((unsigned long int*)(x)) = ret;
    }else{
        if(ret > 50){
            return 0;
        }
        *((int*)(x)) = (unsigned int)ret;
    }
    return 1;
}


int lit_fichier(char *nom, Niveau **niv){
    unsigned int i, j, compte = 0;
    char buf[50], cara;
    unsigned long int inter, allu;
    Coordonnees taille;
    FILE *fichier;

    assert(nom != NULL);

    fichier = fopen(nom, "r");

    if(fichier == NULL){
        /*fprintf(stderr, "ce fichier n'existe pas\n");*/
        return 0;
    }

    if(!lit_nbr(&(taille.x), 0, fichier) || taille.x <= 0){
        return 0;
    }
    if(!lit_nbr(&(taille.y), 0, fichier) || taille.y <= 0){
        return 0;
    }
    (*niv) = malloc_Niveau(taille);
    if((*niv) == NULL){
        return 0;
    }
    for(i = 0; i < taille.y; i++){

        for(j = 0; j < taille.x; j++ ){
            cara = fgetc(fichier);
            if(cara > '9' || cara < '0'){
                fprintf(stderr, "erreur : %d\n", cara);
                return 0;
            }
            buf[0] = cara;
            buf[1] = '\0';
            (*niv) -> objets[j][(*niv) -> taille.y - i - 1].type = atoi(buf);
            if((*niv) -> objets[j][(*niv) -> taille.y - i - 1].type == PERSONNAGE){
                (*niv) -> coo_perso.x = j;
                (*niv) -> coo_perso.y = (*niv) -> taille.y - i - 1;
            }
            if((*niv) -> objets[j][(*niv) -> taille.y - i - 1].type == LANCEUR){
                compte += 1;
            }
            (*niv) -> objets[j][(*niv) -> taille.y - i - 1].donnee_suppl = NULL;
        }+
        fgetc(fichier);
    }
    for(i = 0; i < compte; i++){
        if(!lit_nbr(&(taille.x), 0, fichier)){
            return 0;
        }
        if(!lit_nbr(&(taille.y), 0, fichier)){
            return 0;
        }
        if((*niv) -> objets[taille.x][taille.y].donnee_suppl != NULL){
            return 0;
        }
        if(!lit_nbr(&(inter), 1, fichier)){
            return 0;
        }
        if(!lit_nbr(&(allu), 1, fichier)){
            return 0;
        }
        (*niv) -> objets[taille.x][taille.y].donnee_suppl = (void*)init_generation(inter, allu);
    }

    return 1;
}


int recopie_chaine(char *dest, char*base, int i){
    int compte = 0;
    while('\0' != base[compte] && '\n' != base[compte]){
        dest[i + compte] = base[compte];
        compte += 1;
    }
    dest[i + compte] = '\0';
    return compte;
}
