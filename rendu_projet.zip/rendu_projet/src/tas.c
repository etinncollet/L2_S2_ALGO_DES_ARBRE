/**
 * tas.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : 16/05/2021
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet de gere les tas
 */
#include "../header/tas.h"


Tas* malloc_Tas(unsigned capacite_initiale){
    Tas * nouv;
    nouv = (Tas *)malloc(sizeof(Tas));
    if(nouv != NULL){
        nouv -> taille = 0;
        nouv -> capacite = capacite_initiale;
        nouv -> valeurs = (Evenement*)calloc(capacite_initiale, sizeof(Evenement));
        if(nouv -> valeurs == NULL){
            free(nouv);
            fprintf(stderr, "erreur d'allocation valeur\n");
        }
    }
    return nouv;
}


void free_Tas(Tas* tas){
    free(tas->valeurs);
    free(tas);
    tas = NULL;
}


bool un_evenement_est_pret(Tas* tas){
    if(tas -> taille != 0){
        if(tas -> valeurs[0].moment < maintenant()){
            return true;
        }
    }
    return false;
}


void affiche_Tas(Tas* tas){
    unsigned int i;
    for(i = 0; i < tas->taille; i++){
        fprintf(stderr, "[%ld, (%d, %d)] /", (tas -> valeurs[i]).moment, (tas -> valeurs[i]).coo_obj.x, (tas -> valeurs[i]).coo_obj.y);
    }
    fprintf(stderr, "\n");
}


/**
 * copie un evenement ev2 dans ev1
 */
static void copie_ev(Evenement *ev1, Evenement ev2){
    ev1 -> moment = ev2.moment;
    ev1 -> coo_obj.x = ev2.coo_obj.x;
    ev1 -> coo_obj.y = ev2.coo_obj.y;
}


/**
 * renvoie le plus grand fils possible qui a comme parent la valeur a l'indice indice
 */
static int fils(Tas T, unsigned int indice){
    if (indice * 2 + 1 >= T.taille){
        return -1;
    }

    if (indice * 2 + 2 >= T.taille){
        return indice * 2 + 1;
    }

    if(T.valeurs[indice * 2 + 1].moment < T.valeurs[indice * 2 + 2].moment){
        return indice * 2 + 1;
    }
    return indice * 2 + 2;
}


/**
 * permet de descendre un element dans le tas
 */
static void descente(Tas * T, unsigned int indice){
    int enfant, parent;
    Evenement tmp;

    if (NULL == T || indice >= T->taille)
        return;

    enfant = fils(*T, indice);
    parent = indice;

    while (enfant > -1 && T -> valeurs[enfant].moment < T -> valeurs[parent].moment){
        copie_ev(&tmp, T -> valeurs[enfant]);
        copie_ev(&(T -> valeurs[enfant]), T -> valeurs[parent]);
        copie_ev(&(T -> valeurs[parent]), tmp);

        parent = enfant;
        enfant = fils(*T, parent);
    }
}


/**
 * permet de faire remonte un element dans le tas
 */
static void remontee(Tas * T, unsigned int indice){
    int enfant, parent;
    Evenement tmp;

    if (NULL == T -> valeurs || indice >= T->taille)
        return;

    enfant = indice;
    parent = (indice - 1) / 2;

    while (enfant > 0 && T -> valeurs[enfant].moment < T -> valeurs[parent].moment){

        copie_ev(&tmp, T -> valeurs[enfant]);
        copie_ev(&(T -> valeurs[enfant]), T -> valeurs[parent]);
        copie_ev(&(T -> valeurs[parent]), tmp);

        enfant = parent;
        parent = (enfant - 1) / 2;
    }
}


/**
 * change la valeur a l'indice indice par l'evenement valeur
 */
static void change(Tas * T, unsigned int indice, Evenement valeur){
    int enfant = fils(*T, indice), parent = (((int)indice) - 1) / 2;
    /*fprintf(stderr, "%d\n", parent);*/
    if(indice > T -> taille){
        return;
    }
    if(parent < 0){
        parent = 0;
    }
    /*fprintf(stderr, "ok 3\n");*/
    copie_ev(&(T->valeurs[indice]), valeur);
    T -> taille -= 1;
    /*fprintf(stderr, "ok 3\n%d | %d\n", indice, parent);*/
    if (T->valeurs[indice].moment < T->valeurs[parent].moment){
        /*fprintf(stderr, "monte\n");*/
        remontee(T, indice);
    }
    else if (T->valeurs[indice].moment > T->valeurs[enfant].moment){
        /*fprintf(stderr, "descend\n");*/
        descente(T, indice);
    }
    /*fprintf(stderr, "ok 3\n");*/
}


int ote_minimum(Tas* tas, Evenement * min){

    if ((NULL == tas && tas -> taille > 0) || min == NULL){
        return 0;
    }
    copie_ev(min, tas -> valeurs[0]);
    change(tas, 0, tas -> valeurs[(tas -> taille) - 1]);
    return 1;
}


int ajoute_evenement(Tas* tas, Evenement n){
    int indice;

    if (NULL == tas || tas -> taille >= tas -> capacite){
        return 0;
    }
    indice = tas -> taille;
    tas -> taille += 1;
    copie_ev(&(tas -> valeurs[indice]), n);
    remontee(tas, indice);

    return 1;
}
