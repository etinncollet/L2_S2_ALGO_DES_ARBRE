/**
 * temps.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : 16/05/2021
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet de gere le temps
 */
#include "../header/temps.h"


long unsigned maintenant(){
    return clock();
}


void millisleep(unsigned long i){
    struct timeval tim;
    tim.tv_sec = 0;
    tim.tv_usec =  i * 1000;
    select(0, NULL, NULL, NULL, &tim);
}
