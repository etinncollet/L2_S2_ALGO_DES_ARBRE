/**
 * niveau.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : 16/05/2021
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet de cree les niveaux du projet
 */
#include "../header/niveau.h"


Niveau* malloc_Niveau (Coordonnees taille){
	Niveau* level;
	unsigned int i, j;

    level = (Niveau*)malloc(sizeof(Niveau));
	if(NULL == level){
		printf("Allocation null level\n");
		return NULL;
	}else{
        level -> taille.x = taille.x;
        level -> taille.y = taille.y;

        level->objets = (Objet**)calloc(taille.x, sizeof(Objet*));
        if(NULL == level->objets){
            free(level);
            fprintf(stderr, "Allocation null level->objets\n");
            return NULL;
        }

        for(i = 0; i < taille.x; i++){
            level->objets[i] = (Objet*)calloc(taille.y, sizeof(Objet));/*car la taille de objet est taille.x / taille.y*/
            if(NULL == level->objets){
                for(j = 0; j < i; j++){
                    free(level->objets[j]);/*ont libere la memoire en cas d'echec*/
                }
                free(level->objets);/*ont libere la memoire en cas d'echec*/
                free(level);/*ont libere la memoire en cas d'echec*/
                fprintf(stderr, "Allocation null level->objets[%d] \n", i);
                return  NULL;
            }

        }
        (*level).coo_perso.x = 0;
        (*level).coo_perso.y = 0;
        (*level).avance = 0;
        (*level).allure_perso = (une_milliseconde*250);
        (*level).depl_perso_autorise = true;
        return level;
	}
}


void free_Niveau (Niveau* niveau){
	unsigned int i, j;

	if(NULL == niveau){
		return;
	}

	for(i=0; i < niveau->taille.x; i++){
	    for(j = 0; j < niveau->taille.y; j++){
	        if(niveau->objets[i][j].type == LANCEUR){
	            free(niveau->objets[i][j].donnee_suppl);
	        }else if(niveau->objets[i][j].type == PROJECTILE){
	            free(niveau->objets[i][j].donnee_suppl);
	        }
	    }
		free(niveau->objets[i]);
		niveau->objets[i] = NULL;
	}

	free(niveau->objets);
	niveau->objets = NULL;

	free(niveau);
	niveau = NULL;


}


Niveau* niveau0(){
	unsigned int i, j;
	Coordonnees taille_0 = {10, 5};
	Niveau* level0 = malloc_Niveau (taille_0);

	for(i = 0; i < taille_0.y;i++){
		for(j = 0; j < taille_0.x; j++){

			level0 -> objets[j][i].type = VIDE;
			level0 -> objets[j][i].donnee_suppl = NULL;

            if(i == 3 && j < 7){
                level0 -> objets[j][i].type = MUR;
            }else if(j == 8 && i != 4){
                level0 -> objets[j][i].type = MUR;
            }
	    }
	}

	level0 -> objets[0][0].type = PERSONNAGE;
	level0 -> objets[0][0].donnee_suppl = NULL;
    level0 -> objets[9][0].type = DESTINATION;
	level0 -> objets[9][0].donnee_suppl = NULL;

	level0 -> objets[0][4].type = LANCEUR;
	level0 -> objets[0][4].donnee_suppl = (void*)init_generation(une_seconde, 300 * une_milliseconde);
	if(NULL == level0 -> objets[0][4].donnee_suppl){
	    return NULL;
	}

	level0 -> objets[5][1].type = LANCEUR;
	level0 -> objets[5][1].donnee_suppl = (void*)init_generation(une_seconde, 300 * une_milliseconde);
	if(NULL == level0 -> objets[5][1].donnee_suppl){
	    return NULL;
	}

    return level0;
}


void affiche_Niveau(Niveau* niveau){
    unsigned int i, j;

    assert(niveau != NULL);
    system("clear");
    for(i = 0; i < niveau->taille.y; i++){
        for(j = 0; j < niveau->taille.x; j++ ){
            if (niveau->objets[j][niveau->taille.y - i - 1].type == VIDE ){
                fprintf(stderr, ".");
            }else if (niveau->objets[j][niveau->taille.y - i - 1].type == LANCEUR ){
                fprintf(stderr, "O");
            }else if (niveau->objets[j][niveau->taille.y - i - 1].type == MUR){
                fprintf(stderr, "#");
            }else if (niveau->objets[j][niveau->taille.y - i - 1].type == PERSONNAGE ){
                fprintf(stderr, "P");
            }else if (niveau->objets[j][niveau->taille.y - i - 1].type == DESTINATION ){
                fprintf(stderr, "D");
            }else if(niveau->objets[j][niveau->taille.y - i - 1].type == PROJECTILE){
                switch(((Deplacement*)(niveau->objets[j][niveau->taille.y - i - 1].donnee_suppl)) -> direction){
                    case HAUT :
                        fprintf(stderr, "^");
                        break;
                    case BAS :
                        fprintf(stderr, "v");
                        break;
                    case GAUCHE :
                        fprintf(stderr, "<");
                        break;
                    case DROITE :
                        fprintf(stderr, ">");
                        break;
                    default:
                        break;
                }
            }else{

            }
        }
        printf("\n");
    }
}


Tas* construit_Tas(Niveau* niveau){
    Tas *nouv;
    unsigned int i, j;
    Evenement ajout;

    assert(niveau != NULL);
    nouv = malloc_Tas(niveau -> taille.x * niveau -> taille.y);
    if(nouv != NULL){
        for(i = 0; i < niveau -> taille.y; i++){
            for(j = 0; j < niveau -> taille.x; j++){
                if(niveau -> objets[j][i].type == LANCEUR){
                    ajout.moment = maintenant() + ((Generation*)(niveau -> objets[j][i].donnee_suppl)) -> intervalle;
                    ajout.coo_obj.x = j;
                    ajout.coo_obj.y = i;
                    if(!ajoute_evenement(nouv, ajout)){
                        return NULL;
                    }
                }
            }
        }
    }
    return nouv;
}


void ajoute_projectile(Niveau *niveau, Tas* tas, Evenement e, Direction dir, unsigned long allu){
    Evenement nouv;
    int tst = 0;
    int tst1, tst2, ref;
    TypeObjet obj;
    switch(dir){
        case HAUT:
            tst1 = e.coo_obj.x;
            tst = (tst2 = e.coo_obj.y + 1);
            ref = niveau -> taille.y;
            obj = niveau -> objets[tst1][tst2].type;
            break;
        case BAS:
            tst1 = e.coo_obj.x;
            tst = (tst2 = e.coo_obj.y - 1);
            ref = niveau -> taille.y;
            obj = niveau -> objets[tst1][tst2].type;
            break;
        case GAUCHE:
            tst = (tst1 = e.coo_obj.x - 1);
            tst2 = e.coo_obj.y;
            ref = niveau -> taille.x;
            obj = niveau -> objets[tst1][tst2].type;
            break;
        case DROITE:
            tst = (tst1 = e.coo_obj.x + 1);
            tst2 = e.coo_obj.y;
            ref = niveau -> taille.x;
            obj = niveau -> objets[tst1][tst2].type;
            break;
        default:
            break;
    }
    if( tst >= 0 && tst < ref && obj == VIDE){
        nouv.coo_obj.x = tst1;
        nouv.coo_obj.y = tst2;
        nouv.moment = maintenant() + allu;
        if(!ajoute_evenement(tas, nouv)){
            return ;
        }
        niveau -> objets[tst1][tst2].type = PROJECTILE;
        niveau -> objets[tst1][tst2].donnee_suppl = (void*)init_deplac(dir, allu);
    }
}


int traite_evenement(Evenement e, Tas* tas, Niveau* niveau){
    Evenement nouv;
    unsigned long allu;
    int tst, direc;
    assert( tas != NULL);
    assert(niveau != NULL);
    if(niveau -> objets[e.coo_obj.x][e.coo_obj.y].type == LANCEUR){
        allu = ((Generation*)niveau -> objets[e.coo_obj.x][e.coo_obj.y].donnee_suppl) -> allure_proj;
        nouv.coo_obj.x = e.coo_obj.x;
        nouv.coo_obj.y = e.coo_obj.y;
        nouv.moment = maintenant() + ((Generation*)niveau -> objets[e.coo_obj.x][e.coo_obj.y].donnee_suppl) -> intervalle;
        ajoute_evenement(tas, nouv);
        if(e.coo_obj.x + 1 < niveau -> taille.x){
            if(niveau -> objets[e.coo_obj.x + 1][e.coo_obj.y].type == PERSONNAGE){
                return 0;
            }
            if(niveau -> objets[e.coo_obj.x + 1][e.coo_obj.y].type == VIDE){
                ajoute_projectile(niveau, tas, e, DROITE, allu);
            }
        }
        tst = e.coo_obj.x - 1;
        if(tst >= 0 ){
            if(niveau -> objets[e.coo_obj.x - 1][e.coo_obj.y].type == PERSONNAGE){
                return 0;
            }
            if(niveau -> objets[e.coo_obj.x - 1][e.coo_obj.y].type == VIDE){
                ajoute_projectile(niveau, tas, e, GAUCHE, allu);
            }
        }
        if((e.coo_obj.y + 1) < niveau -> taille.y){
            if(niveau -> objets[e.coo_obj.x][e.coo_obj.y + 1].type == PERSONNAGE){
                return 0;
            }
            if(niveau -> objets[e.coo_obj.x][e.coo_obj.y + 1].type == VIDE){
                ajoute_projectile(niveau, tas, e, HAUT, allu);
            }

        }
        tst = e.coo_obj.y - 1;
        if(tst >= 0){
            if(niveau -> objets[e.coo_obj.x][e.coo_obj.y - 1].type == PERSONNAGE){
                return 0;
            }
            if(niveau -> objets[e.coo_obj.x][e.coo_obj.y - 1].type == VIDE){
                ajoute_projectile(niveau, tas, e, BAS, allu);
            }

        }
    }
    else if(niveau -> objets[e.coo_obj.x][e.coo_obj.y].type == PROJECTILE){
        allu = ((Deplacement*)niveau -> objets[e.coo_obj.x][e.coo_obj.y].donnee_suppl) -> allure;
        direc = ((Deplacement*)niveau -> objets[e.coo_obj.x][e.coo_obj.y].donnee_suppl) -> direction;

        niveau -> objets[e.coo_obj.x][e.coo_obj.y].type = VIDE;
        free(niveau -> objets[e.coo_obj.x][e.coo_obj.y].donnee_suppl);
        niveau -> objets[e.coo_obj.x][e.coo_obj.y].donnee_suppl = NULL;
        if(direc == HAUT){
            if(e.coo_obj.y + 1 < niveau -> taille.y){
                if(niveau -> objets[e.coo_obj.x][e.coo_obj.y + 1].type == PERSONNAGE){
                    return 0;
                }
                if(niveau -> objets[e.coo_obj.x][e.coo_obj.y + 1].type == VIDE){
                    ajoute_projectile(niveau, tas, e, HAUT, allu);
                }
            }
        }else if(direc == BAS){
            tst = e.coo_obj.y - 1;
            if( tst >= 0){
                if(niveau -> objets[e.coo_obj.x][tst].type == PERSONNAGE){
                    return 0;
                }
                if(niveau -> objets[e.coo_obj.x][tst].type == VIDE){
                    ajoute_projectile(niveau, tas, e, BAS, allu);
                }
            }
        }else if(direc == GAUCHE){
            tst = e.coo_obj.x - 1;
            if( tst >= 0 ){
                if(niveau -> objets[tst][e.coo_obj.y].type == PERSONNAGE){
                    return 0;
                }
                if(niveau -> objets[tst][e.coo_obj.y].type == VIDE){
                    ajoute_projectile(niveau, tas, e, GAUCHE, allu);
                }
            }
        }else if(direc == DROITE){
            if(e.coo_obj.x + 1 < niveau -> taille.x){
                if(niveau -> objets[e.coo_obj.x + 1][e.coo_obj.y].type == PERSONNAGE){
                    return 0;
                }
                if(niveau -> objets[e.coo_obj.x + 1][e.coo_obj.y].type == VIDE){
                    ajoute_projectile(niveau, tas, e, DROITE, allu);
                }
            }
        }
    }
    return 1;
}
