/**
 * moteur.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : 16/05/2021
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet de faire fonctionner les niveaux et le projet
 */
#include "../header/config_stdin.h"
#include "../header/moteur.h"
#include <unistd.h>


/**
 * verifie que l'on ne quitte pas par erreur
 */
static int quitter(unsigned int longueur, unsigned int largeur, char *texte){
    int x_c, y_c, x, y;
    affiche_exit(longueur, largeur, &x, &y, texte);
    MLV_wait_mouse(&x_c, &y_c);
    if( (unsigned)x_c > (longueur / 2) - (x / 2) - 60 && (unsigned)x_c < (longueur / 2) + (x / 2) + 60 && (unsigned)y_c > (largeur / 2) - (y / 2) + 130 && (unsigned)y_c < (largeur / 2) + (y / 2) + 170){
        return 1;
    }
    return 0;
}


/**
 * Deplace le personnage dans la direction en parametre dans le niveaux
 * Si cela est possible
 * Renvoie 2 si ont arrive a l'arriver
 * Renvoie 0 si ont perd
 * Renvoie 1 sinon
 */
static int deplace_perso(Direction dir, Niveau *niv){
    int tst, tstx, tsty, rep, coef;
    unsigned int *opera;
    switch(dir){
        case DROITE :
            rep = (tstx = ((niv -> coo_perso.x) + 1));
            tsty = niv -> coo_perso.y;
            tst = (int)(niv -> taille.x);
            coef = 1;
            opera = &(niv -> coo_perso.x);
            break;
        case GAUCHE :
            tst = (tstx = ((niv -> coo_perso.x) - 1));
            tsty = niv -> coo_perso.y;
            rep = -1;
            coef = -1;
            opera = &(niv -> coo_perso.x);
            break;
        case HAUT :
            rep = (tsty = ((niv -> coo_perso.y) + 1));
            tstx = niv -> coo_perso.x;
            tst = (int)(niv -> taille.y);
            coef = 1;
            opera = &(niv -> coo_perso.y);
            break;
        case BAS :
            tst = (tsty = ((niv -> coo_perso.y) - 1));
            tstx = niv -> coo_perso.x;
            rep = -1;
            coef = -1;
            opera = &(niv -> coo_perso.y);
            break;
        default:
            break;
    }
    if( tst > rep && niv -> depl_perso_autorise){
        if(niv -> objets[tstx][tsty].type != VIDE){
            if(niv -> objets[tstx][tsty].type == DESTINATION)
                return 2;
            if(niv -> objets[tstx][tsty].type == PROJECTILE)
                return 0;
            return 1;
        }
        niv -> objets[niv -> coo_perso.x][niv -> coo_perso.y].type = VIDE;
        (*opera) += coef;
        niv -> objets[niv -> coo_perso.x][niv -> coo_perso.y].type = PERSONNAGE;
        niv -> avance = maintenant();
        niv -> depl_perso_autorise = false;
    }
    return 1;
}


/**
 * Prend en parametre une touche et modifie le niveaux en fonction de la touche
 * Renvoie 2 en cas de victoire
 * Renvoie 1 sinon
 */
static int traite_touche(char touch, Niveau *niv){
    assert( niv != NULL);
    if((maintenant() - (niv -> avance)) > niv -> allure_perso){
        niv -> depl_perso_autorise = true;
    }
    switch(touch){
        case 'q':
            return deplace_perso(GAUCHE, niv);
        case 's':
            return deplace_perso(BAS, niv);
        case 'd':
            return deplace_perso(DROITE, niv);
        case 'z':
            return deplace_perso(HAUT, niv);
        default:
            return 1;
    }
    return 1;
}


/**
 * Permet de jouer le niveaux 0
 * Renvoie 0 en cas d'erreur sinon 1
 */
static int joue_test(Niveau* niveau){
    Tas* tas = construit_Tas(niveau);
    Evenement e;
    int touche;
    char cara;
    if(niveau == NULL){
        free_Tas(tas);
        return 0;
    }
    init_stdin();
    affiche_Niveau(niveau);
    while (true) {
        cara = getchar();
        if(cara != EOF){
            touche = traite_touche(cara, niveau);
            if(touche == 0){
                restaure_stdin();
                free_Tas(tas);
                return 0;
            }else if(touche == 2){
                restaure_stdin();
                free_Tas(tas);
                return 1;
            }
        }
        if(un_evenement_est_pret(tas)) {
            ote_minimum(tas, &e);
            if(!traite_evenement(e, tas, niveau)){
                restaure_stdin();
                free_Tas(tas);
                return 0;
            }
            affiche_Niveau(niveau);
        }
    }
    restaure_stdin();
}


/**
 * Verifie les click dans la bare vertical en fonction du nombre de case
 * Renvoie 0 si le cilck de coordonnée x, y n'est pas dedand
 * Sinon entre 1 et nombre
 */
static int verif_clik_menu_graphique(int nombre, int x, int y){
    int i;
    for(i = 0; i < nombre; i++){
        if(x > (250 * i) && x < (250 * (i + 1)) && y > 0 && y < 75){
            return i + 1;
        }
    }
    return 0;
}


/**
 * Attend un click
 * Renvoie ce que renvoie verif_clik_menu_graphique(int nombre, int x, int y)
 */
static int clik_menu_graphique(int nombre){
    int x, y;
    MLV_wait_mouse(&x, &y);
    return verif_clik_menu_graphique(nombre, x, y);
}


/**
 * Permet de jouer le niveaux 0
 * Renvoie 0 en cas d'erreur sinon 1
 */
static int joue_test_graph(unsigned int longueur, unsigned int largeur, Niveau* niveau){
    /*fprintf(stderr, "ok3\n%p, %d, %d", niveau, niveau -> taille.x, niveau -> taille.y);
    affiche_Niveau(niveau);*/
    #undef CONST
    Tas* tas = construit_Tas(niveau);
    /*fprintf(stderr, "ok3\n");*/
    MLV_Event ev;
    MLV_Image *ima;
    int mouse_x, mouse_y, click, touche;
    MLV_Keyboard_button cara;
    MLV_Button_state etat;
    Evenement e;
    char nom[2][TMOTS] = {"MENU", "QUITTER"};
    if(niveau == NULL){
        free_Tas(tas);
        return 0;
    }
    ima = MLV_load_image("./image/image_fond.png");
    MLV_resize_image(ima, longueur, largeur);
    MLV_draw_image(ima, 0, 0);
    affiche_menu(nom, 2);
    affiche_graph_niv(longueur, largeur, *niveau, 0);
    MLV_wait_milliseconds(10);
    ev = MLV_get_event(NULL, NULL, NULL, NULL, NULL, &mouse_x, &mouse_y, NULL, NULL);
    mouse_x = longueur;
    mouse_y = largeur;
    while (true) {
        ev = MLV_get_event(&cara, NULL, NULL, NULL, NULL, &mouse_x, &mouse_y, NULL, &etat);
        if(ev == MLV_KEY || etat == MLV_PRESSED){
            touche = traite_touche(cara, niveau);
            if(touche == 0){
                free_Tas(tas);
                return 0;
            }else if(touche == 2){
                free_Tas(tas);
                return 1;
            }
        }else if(ev == MLV_MOUSE_BUTTON){
            click = verif_clik_menu_graphique(2, mouse_x, mouse_y);
            if(click == 1){
                free_Tas(tas);
                return 2;
            }else if(click == 2){
                free_Tas(tas);
                return -1;
            }
        }
        if((tas -> taille) == 0){
            affiche_graph_niv(longueur, largeur, *niveau, 0);
        }else{
            if(un_evenement_est_pret(tas)) {
                ote_minimum(tas, &e);
                if(!traite_evenement(e, tas, niveau)){
                    free_Tas(tas);
                    return 0;
                }
                affiche_graph_niv(longueur, largeur, *niveau, 0);
            }else{
                usleep(100);
            }
        }
    }
}


/**
 * Compare les chaines "premiere" et "deuxieme"
 * Renvoie 0 si ce sont les meme
 * Renvoie -1 si premiere est superieure
 * Renvoie 1 si deuxieme est superieure
 */
static int compare_chaine(char * premiere, char * deuxieme){
    int i;
    assert(premiere != NULL);
    assert(deuxieme != NULL);
    i = 0;
    while(1){
        if(premiere[i] == deuxieme[i]){
            if(premiere[i] == '\0'){
                return 0;
            }
            i++;
            continue;
        }
        if(premiere[i] < deuxieme[i]){
            return 1;
        }else{
            return -1;
        }
    }
}


/**
 * Lit les arguments et
 * Renvoie 0 si il n'y en a pas
 * Renvoie un entier superieur a 0 selon l'argument
 * Renvoie -1 si celui ci est invalide
 */
static int lit_argument(int argc, char **argv){
    char argu[10][10] = {"--usage", "--f", "--test=0", "--test=1"};
    int max_arg = 4, i;
    FILE *fichier;

    assert(argv != NULL);

    if(argc == 1){
        return 0;
    }
    for(i = 0; i < max_arg; i++){
        if(compare_chaine(argu[i], argv[1]) == 0){
            if(i == 1){
                if(argc != 3){
                    fprintf(stderr, "ERREUR : Il y a un probleme avec les arguments de l'option \"--f\"\n\n");
                    return -1;
                }
                fichier = fopen(argv[2], "r");
                if(fichier == NULL){
                    fprintf(stderr, "ERREUR : Le fichier \"%s\" en paramettre n'existe pas\n", argv[2]);
                    return -1;
                }
            }
            return i + 1;
        }
    }
    return -1;
}


/**
 * Permet de cliquer pour modifier les paramettre des choix
 */
static int click_modi_base(unsigned int longueur, int x, int y){
    int x_base = (longueur) / 2 - (longueur - 200) / 5, y_base1 = 300, y_base2 = 500;
    int x_txt = (longueur) / 2 + 160, y_txt = 400;
    if( x < x_base && x > x_base -75 && y < y_base1 + 75 && y > y_base1){
        return 1;
    }else if(x < x_base + 225 && x > x_base + 150 && y < y_base1 + 75 && y > y_base1){
        return 2;
    }else if( x < x_base && x > x_base -75 && y < y_base2 + 75 && y > y_base2){
        return 3;
    }else if( x < x_base + 225 && x > x_base + 150 && y < y_base2 + 75 && y > y_base1){
        return 4;
    }else if( x < x_txt && x > x_txt - 75 && y < y_txt + 75 && y > y_txt){
        return 5;
    }else if( x < x_txt + 375 && x > x_txt + 300 && y < y_txt + 75 && y > y_txt){
        return 6;
    }
    return 0;
}


/**
 * Affiche les choix de base des paramettre pour la creation
 */
static void affiche_base_choix(int nombre, int longueur, int largeur, Coordonnees *taille){
    if(nombre == 0){
        affiche_choix_taille(longueur, largeur, 1);
        MLV_draw_text((longueur) / 2 - 550, 310, "LONGUEUR", MLV_COLOR_BLACK);
        MLV_draw_text((longueur) / 2 - 550, 510, "LARGEUR", MLV_COLOR_BLACK);
        affiche_choix_nombre((longueur) / 2 - (longueur - 200) / 5 , 300, taille -> x);
        affiche_choix_nombre((longueur) / 2 - (longueur - 200) / 5 , 500, taille -> y);
    }else{
        affiche_choix_taille(longueur, largeur, 1);
        affiche_choix_fichier(longueur, largeur, 1);
        MLV_draw_text((longueur) / 2 - 550, 310, "LONGUEUR", MLV_COLOR_BLACK);
        MLV_draw_text((longueur) / 2 - 550, 510, "LARGEUR", MLV_COLOR_BLACK);
        affiche_choix_nombre((longueur) / 2 - (longueur - 200) / 5 , 300, taille -> x);
        affiche_choix_nombre((longueur) / 2 - (longueur - 200) / 5 , 500, taille -> y);
        MLV_draw_text((longueur) / 2 + 160, 300, "FICHIER A TELECHARGER", MLV_COLOR_BLACK);
        affiche_choix_txt((longueur) / 2 + 160, 400, "SANS");
    }
}


/**
 * Modifie les paramettre pour la creation et les renvoie
 */
static void modifie_choix_base(int tst2, Coordonnees *taille, int *parcour, char ** nom_fichier, int nombre, unsigned int longueur){
    if(tst2 != 0){
        switch(tst2){
            case 1:
                if(taille -> x - 1 > 3){
                    taille -> x -= 1;
                }
                break;
            case 2:
                if(taille -> x + 1 < 16){
                    taille -> x += 1;
                }
                break;
            case 3:
                if(taille -> y - 1 > 3){
                    taille -> y -= 1;
                }
                break;
            case 4:
                if(taille -> y + 1 < 16){
                    taille -> y += 1;
                }
                break;
            case 5:

                if((*parcour) - 1 > -2 && nombre != 0){
                    (*parcour) -= 1;
                }
                break;
            case 6:
                if((*parcour) + 1 < nombre && nombre != 0){
                    (*parcour) += 1;
                }
                break;
        }
        affiche_choix_nombre((longueur) / 2 - (longueur - 200) / 5 , 300, taille -> x);
        affiche_choix_nombre((longueur) / 2 - (longueur - 200) / 5 , 500, taille -> y);
        if(nombre != 0){
            if((*parcour) == -1){
                affiche_choix_txt((longueur) / 2 + 160, 400, "SANS");
            }else{
                affiche_choix_txt((longueur) / 2 + 160, 400, nom_fichier[(*parcour)]);
            }
        }
        MLV_update_window();
    }
}


/**
 * Permet de choisir si l'ont veux cree un nouveaux niveaux ou si l'ont veux commencer avec un niveaux deja existant
 */
static int choisie_base_crea(unsigned int longueur, unsigned int largeur, Coordonnees *taille, Niveau **niv){
    char nom[3][TMOTS] = {"VALIDER", "MENU", "QUITTER"};
    char **nom_fichier = NULL;
    int tst, tst2, x, y, nombre, parcour = -1;
    MLV_Image *ima;
    assert(taille != NULL);
    assert(niv != NULL);

    ima = MLV_load_image("./image/image_fond.png");
    MLV_resize_image(ima, longueur, largeur);
    MLV_draw_image(ima, 0, 0);
    MLV_free_image(ima);
    if(!fichier_niveaux(&nom_fichier, &nombre)){
        fprintf(stderr, "il y a eu une erreur dans : fichier_niveaux()\n");
        return 0;
    }
    affiche_base_choix(nombre, longueur, largeur, taille);
    affiche_menu(nom, 3);
    do{
        MLV_wait_mouse(&x, &y);
        tst = verif_clik_menu_graphique(3, x, y);
        if(tst == 1){
            /*fprintf(stderr, "valider\n");*/
            if(parcour != -1){
                char tableaux[100];
                /*fprintf(stderr, "base\n");*/
                sprintf(tableaux, "./niveaux/%s", nom_fichier[parcour]);
                lit_fichier(tableaux, niv);
            }
            free_lst(nom_fichier, nombre);
            return 1;
        }else if(tst == 2){
            free_lst(nom_fichier, nombre);
            return 0;
        }
        tst2 = click_modi_base(longueur, x, y);
        modifie_choix_base(tst2, taille, &parcour, nom_fichier, nombre, longueur);
    }while(tst != 3);
    free_lst(nom_fichier, nombre);
    return -1;
}


/**
 * Verifie si l'on a cliquer sur une case
 * Si oui ont renvoie un nombre entre 1 et 8
 * Sinon 0
 */
static int tst_click_niveau(unsigned int longueur, unsigned int largeur, int x, int y){
    int lon = (longueur - 250) / 2, lar = (largeur - 280) / 4;
    int i, j;
    for(i = 0; i < 2; i++){
        for(j = 0; j < 4; j++){
            if( x > 100 + (i * lon) + (i * 50) && x < 100 + (i * lon) + (i * 50) + lon && y > 100 + (j * lar) + (j * 20) && y < 100 + (j * lar) + (j * 20) + lar){
                return(i * 4) + j;
            }
        }
    }
    return -1;
}


/**
 * Permet de choisir un niveaux
 * Renvoie -1 si l'ont veux quitter le jeux
 * Renvoie 0 si l'ont revient au menu
 * Sinon renvoie le nombre du niveaux entre 1 et 8
 */
static int choix_niveau_hist(unsigned int longueur, unsigned int largeur){
    int tst, tst2, x, y, choix = 0;
    char nom[3][TMOTS] = {"VALIDER", "MENU", "QUITTER"};
    MLV_Image *ima;
    ima = MLV_load_image("./image/image_fond.png");
    MLV_resize_image(ima, longueur, largeur);
    MLV_draw_image(ima, 0, 0);
    MLV_free_image(ima);
    affiche_menu(nom, 3);
    do{
        affiche_niveau_hist(longueur, largeur, choix);
        MLV_wait_mouse(&x, &y);
        tst = verif_clik_menu_graphique(3, x, y);
        if(tst == 1){
            return choix + 1;
        }else if(tst == 2){
            return 0;
        }
        tst2 = tst_click_niveau(longueur, largeur, x, y);
        if(tst2 != -1){
            choix = tst2;
        }
    }while(tst != 3);
    return -1;
}


/**
 * Permet de jouer au different niveaux qui sont en mode histoire
 */
static int mode_histoire(unsigned int longueur, unsigned int largeur){
    int tst;
    Niveau * niv;
    char base[50] = "./histoire/", nom_n[8][20] = {"niveau0.NIV", "niveau1.NIV", "niveau2.NIV", "niveau3.NIV", "niveau4.NIV", "niveau5.NIV", "niveau6.NIV", "niveau7.NIV"};
    do{
        tst = choix_niveau_hist(longueur, largeur);
        if(tst == -1){
            if(quitter(longueur, largeur, "voulez-vous vraiment partir ?")){
                return 0;
            }
            continue;
        }else if(tst == 0){
            return 1;
        }else{
            recopie_chaine(base, nom_n[tst - 1], 11);
            /*fprintf(stderr, "%s\n", base);*/
            tst = lit_fichier(base, &niv);
            if(tst == 0){
                return 1;
            }
        }
        break;
    }while(true);

    tst = joue_test_graph(longueur, largeur, niv);
    free_Niveau(niv);
    switch(tst){
        case 0:
            affiche_paneaux_centre(longueur, largeur, "Vous avez perdu");
            break;
        case -1:
            affiche_paneaux_centre(longueur, largeur, "Vous avez Quitte");
            return 0;
        case 1:
            affiche_paneaux_centre(longueur, largeur, "Vous avez gagne");
            break;
        case 2:
            affiche_paneaux_centre(longueur, largeur, "Vous avez abandonne");
            break;
    }
    return 1;
}


/**
 * Verifie les click dans la bare verticale en mode createur
 */
static int verif_clik_bare_graphique(unsigned int x, unsigned int y, unsigned int longueur, unsigned int largeur){
    unsigned int cas = (largeur - 150) / 6, i;
    for(i = 0; i < 5; i++){
        if(x < longueur && x > (longueur - cas) && y < largeur - (i * cas) && y > largeur - ((i + 1) * cas)){
            return i + 1;
        }
    }
    return 0;
}


/**
 * Permet de cliquer dans un niveaux
 * Renvoie 0 si l'ont click a coter sinon 1
 */
static int verif_clik_niveau_graphique(unsigned int x, unsigned int y, unsigned int longueur, unsigned int largeur, int obj, Niveau* niv, Coordonnees *donne){
    unsigned int max, i, j;
    max = mini((largeur - 150) / niv -> taille.y, (longueur - 200) / niv -> taille.x);
    if( x < DEBUTX || x > DEBUTX + (niv -> taille.x * max) || y < DEBUTY || y > DEBUTY + (niv -> taille.y * max)){
        return 0;
    }
    for(i = 0; i < niv -> taille.y; i++){
        for(j = 0; j < niv -> taille.x; j++){
            if(x > (DEBUTX + (j * max)) && x < (DEBUTX + ((j + 1) * max)) && y > (DEBUTY + (i * max)) && y < (DEBUTY + ((i + 1) * max))){
                if((obj == PERSONNAGE && donne -> x == 1) || (obj == DESTINATION && donne -> y == 1)){
                    return 1;
                }
                if(niv -> objets[j][niv -> taille.y - i - 1].type == PERSONNAGE && obj != PERSONNAGE){
                    donne -> x = 0;
                }
                if(niv -> objets[j][niv -> taille.y - i - 1].type == DESTINATION && obj != DESTINATION){
                    donne -> y = 0;
                }
                niv -> objets[j][niv -> taille.y - i - 1].type = obj;

                if(obj == LANCEUR){
                    if(niv -> objets[j][niv -> taille.y - i - 1].donnee_suppl != NULL){
                        free(niv -> objets[j][niv -> taille.y - i - 1].donnee_suppl);
                    }
                    niv -> objets[j][niv -> taille.y - i - 1].donnee_suppl = (void*)init_generation(une_seconde, une_milliseconde * 300);

                }else{
                    if(obj == PERSONNAGE){
                        donne -> x = 1;
                    }
                    if(obj == DESTINATION){
                        donne -> y = 1;
                    }
                    if(niv -> objets[j][niv -> taille.y - i - 1].donnee_suppl != NULL){
                        free(niv -> objets[j][niv -> taille.y - i - 1].donnee_suppl);
                    }
                    niv -> objets[j][niv -> taille.y - i - 1].donnee_suppl = NULL;
                }
                return 1;
            }
        }
    }
    return 0;
}


/**
 * Permet de cree un niveaux
 * L'affichage depend de la longueur et de la largueur de la fenetre passer en argument
 * Renvoie 0 en cas d'erreur sinon 1
 */
static int mode_creatore(unsigned int longueur, unsigned int largeur){
    int x, y, tst;
    char nom[3][TMOTS] = {"SAUVEGARDE", "MENU", "QUITTER"}, *nouv_fich;
    int nombre, objet = 0;
    Niveau* niv = NULL;
    Coordonnees taille, donne;
    MLV_Image *ima;
    MLV_Font *font = MLV_load_font("./ttf/coolvetica.ttf", 45);
    donne.x = 0;
    donne.y = 0;
    taille.x = 4;
    taille.y = 4;

    nouv_fich = (char*)calloc(50, sizeof(char));
    if(NULL == nouv_fich){
        return 0;
    }
    do{
        tst = choisie_base_crea(longueur, largeur, &taille, &niv);
        if(tst == -1){
            if(quitter(longueur, largeur, "voulez-vous vraiment partir ?")){
                MLV_free_font(font);
                free(nouv_fich);
                free_Niveau(niv);
                return 0;
            }
            continue;
        }else if(tst == 0){
            MLV_free_font(font);
            free(nouv_fich);
            free_Niveau(niv);
            return 1;
        }
        break;
    }while(true);

    if(niv == NULL){
        niv = malloc_Niveau(taille);
        if(niv == NULL){
            free(nouv_fich);
            return 0;
        }
    }else{
        donne.x = 1;
        donne.y = 1;
    }

    ima = MLV_load_image("./image/image_fond.png");
    MLV_resize_image(ima, longueur, largeur);
    MLV_draw_image(ima, 0, 0);
    MLV_free_image(ima);
    affiche_menu(nom, 3);
    do{
        affiche_graph_niv(longueur, largeur, *niv, 1);
        affiche_bare_latterale(longueur, largeur, objet);
        MLV_wait_mouse(&x, &y);
        tst = verif_clik_menu_graphique(3, x, y);
        if(tst == 1){
            int ret;
            if(donne.x != 1 || donne.y != 1){
                affiche_paneaux_centre(longueur, largeur, "Il manque des elements");
                /*fprintf(stderr, "il manque quelque chose\n");*/
                continue;
            }
            /*fprintf(stderr, "sauvegarde\n");*/
            while(true){
                MLV_wait_input_box_with_font(200, 200, longueur - 400, largeur - 400, MLV_COLOR_BLACK, MLV_COLOR_BLACK, MLV_COLOR_GREY, "       NOM DE LA SAUVEGARDE : ", &nouv_fich, font);
                ret = note_dans_f(*niv, niv -> taille.x * niv -> taille.y, nouv_fich);
                if( ret == 0){
                    /*fprintf(stderr, "ERREUR : dans la sauvegarde\n");*/
                    affiche_paneaux_centre(longueur, largeur, "Erreur dans la sauvegarde");
                    break;
                }else if(ret == 2){
                    affiche_paneaux_centre(longueur, largeur, "Le fichier existe deja");
                    continue;
                }else{
                    affiche_paneaux_centre(longueur, largeur, "Sauvegarde correcte");
                    break;
                }
            }
            MLV_free_font(font);
            free(nouv_fich);
            free_Niveau(niv);
            return 1;
        }else if(tst == 2){
            MLV_free_font(font);
            free(nouv_fich);
            free_Niveau(niv);
            return 1;
        }else if(tst == 3){
            if(!quitter(longueur, largeur, "voulez-vous vraiment partir ?")){
                tst = 0;
                MLV_draw_filled_rectangle(100, 100, longueur - 250, largeur, MLV_COLOR_WHITE);
                continue;
            }
        }
        nombre = verif_clik_bare_graphique(x, y, longueur, largeur);
        if(nombre != 0){
            objet = nombre - 1;
        }
        verif_clik_niveau_graphique(x, y, longueur, largeur, objet, niv, &donne);
    }while(tst != 3);
    free(nouv_fich);
    MLV_free_font(font);
    free_Niveau(niv);
    return 0;
}


/**
 * Permet d'ouvrir un fichier dans le mode graphique
 * L'affichage depend de la longueur et de la largueur de la fenetre passer en argument
 * Renvoie 0 en cas d'erreur sinon 1
 */
static int mode_fichier(unsigned int longueur, unsigned int largeur){
    char nom1[3][TMOTS] = {"TELECHARGER", "MENU", "QUITTER"};
    char nom2[2][TMOTS] = {"MENU", "QUITTER"};
    char **nom_fichier = NULL;
    int tst, tst2, x, y, nombre, parcour = 0, annul = 0;
    MLV_Image *ima;
    Niveau *niv;
    if(!fichier_niveaux(&nom_fichier, &nombre)){
        fprintf(stderr, "il y a eu une erreur dans : fichier_niveaux()\n");
        return 0;
    }
    ima = MLV_load_image("./image/image_fond.png");
    MLV_resize_image(ima, longueur, largeur);
    MLV_draw_image(ima, 0, 0);
    if(nombre != 0){
        affiche_choix_fichier(longueur, largeur, 0);
        MLV_draw_text((longueur) / 2 + 130, 300, "FICHIER A TELECHARGER", MLV_COLOR_BLACK);
        affiche_menu(nom1, 3);
    }else{
        affiche_choix_fichier(longueur, largeur, 0);
        MLV_draw_text((longueur) / 2 + 130, 300, "AUCUN FICHIER .NIV TROUVER", MLV_COLOR_BLACK);
        affiche_menu(nom2, 2);
    }

    do{
        if(nombre != 0){
            affiche_choix_txt((longueur) / 2 + 160, 400, nom_fichier[parcour]);
            MLV_wait_mouse(&x, &y);
            tst = verif_clik_menu_graphique(3, x, y);
            if(tst == 1){
                char tableaux[100];
                /*fprintf(stderr, "telecharger\n");*/
                sprintf(tableaux, "./niveaux/%s", nom_fichier[parcour]);
                /*fprintf(stderr, "%s\n", tableaux);*/
                lit_fichier(tableaux, &niv);
                tst = joue_test_graph(longueur, largeur, niv);
                switch(tst){
                    case 0:
                        affiche_paneaux_centre(longueur, largeur, "vous avez perdu");
                        break;
                    case -1:
                        affiche_paneaux_centre(longueur, largeur, "vous avez quitte");
                        free_lst(nom_fichier, nombre);
                        return 0;
                    case 1:
                        affiche_paneaux_centre(longueur, largeur, "vous avez gagne");
                        /*fprintf(stderr, "vous avez gagner\n");*/
                        break;
                    case 2:
                        affiche_paneaux_centre(longueur, largeur, "vous avez abandonne");
                        /*fprintf(stderr, "vous avez abandonner\n");*/
                        break;
                }
                if(annul){
                    /*fprintf(stderr, "ok");*/
                    continue;
                }
                free_lst(nom_fichier, nombre);
                return 1;
            }else if(tst == 3){
                if(!quitter(longueur, largeur, "voulez-vous vraiment partir ?")){
                    /*fprintf(stderr, "annul2\n");*/
                    MLV_clear_window(MLV_COLOR_WHITE);
                    if(nombre != 0){
                        affiche_choix_fichier(longueur, largeur, 0);
                        MLV_draw_text((longueur) / 2 + 130, 300, "FICHIER A TELECHARGER", MLV_COLOR_BLACK);
                        affiche_menu(nom1, 3);
                    }else{
                        affiche_choix_fichier(longueur, largeur, 0);
                        MLV_draw_text((longueur) / 2 + 130, 300, "AUCUN FICHIER .NIV TROUVER", MLV_COLOR_BLACK);
                        affiche_menu(nom2, 2);
                    }
                    tst = 0;
                    continue;
                }
                free_lst(nom_fichier, nombre);
                return 0;
            }else if(tst == 2){
                free_lst(nom_fichier, nombre);
                return 1;
            }
            tst2 = click_modi_base(longueur, x, y);
            if(tst2 > 4){
                if(tst2 == 5 && parcour - 1 > -1 && nombre != 0){
                    parcour -= 1;
                }
                if(tst2 == 6 && parcour + 1 < nombre && nombre != 0){
                    parcour += 1;
                }
            }
        }else{
            MLV_wait_mouse(&x, &y);
            tst = verif_clik_menu_graphique(2, x, y);
            if(tst == 1){
                free_lst(nom_fichier, nombre);
                return 1;
            }else if(tst == 2){
                free_lst(nom_fichier, nombre);
                return 0;
            }
        }
    }while(tst != 3);
    free_lst(nom_fichier, nombre);
    return 0;
}


void utilise_argv(int argc, char **argv){
    int tst = lit_argument(argc, argv), click;
    char nom[4][TMOTS] = {"HISTOIRE", "FICHIER", "CREATORE", "QUITTER"};
    unsigned int longueur, largeur;
    Niveau *niv;
    switch(tst){
        case -1:
            fprintf(stderr, "ERREUR : il y a une erreur dans les arguments\nutiliser l'argument \"--usage\" pour connaitre tous les arguments possible\n");
            break;
        case 0:
            ouvre_fenettre(&longueur, &largeur);
            {
                MLV_Image *ima;
                ima = MLV_load_image("./image/image.png");
                MLV_resize_image(ima, longueur, largeur);
                MLV_draw_image(ima, 0, 0);
                affiche_menu(nom, 4);

                do{
                    click = clik_menu_graphique(4);
                    if(click == 1){
                        if(!mode_histoire(longueur, largeur)){
                            MLV_free_window();
                            MLV_free_image(ima);
                            return ;
                        }
                        MLV_draw_image(ima, 0, 0);
                        affiche_menu(nom, 4);
                        MLV_update_window();
                    }else if(click == 3){
                        if(!mode_creatore(longueur, largeur)){
                            MLV_free_window();
                            MLV_free_image(ima);
                            return ;
                        }
                        MLV_draw_image(ima, 0, 0);
                        affiche_menu(nom, 4);
                        MLV_update_window();
                    }else if(click == 2){
                        if(!mode_fichier(longueur, largeur)){
                            MLV_free_window();
                            MLV_free_image(ima);
                            return ;
                        }
                        MLV_draw_image(ima, 0, 0);
                        affiche_menu(nom, 4);
                        MLV_update_window();
                    }else if(click == 4){
                        if(!quitter(longueur, largeur, "voulez-vous vraiment partir ?")){
                            click = 0;
                            MLV_draw_image(ima, 0, 0);
                            affiche_menu(nom, 4);
                            MLV_update_window();
                            continue;
                        }
                    }
                }while(click != 4);
                MLV_free_image(ima);
            }
            MLV_free_window();
            break;
        case 3:
            if(!joue_test(niveau0())){
                system("clear");
                fprintf(stderr, "vous avez perdu\n");
            }else{
                system("clear");
                fprintf(stderr, "vous avez gagne\n");
            }
            break;
        case 1:
            affiche_usage();
            break;
        case 4:
            ouvre_fenettre(&longueur, &largeur);
            while(!quitter(longueur, largeur, "etes-vous pret a jouer")){
            }
            tst = joue_test_graph(longueur, largeur, niveau0());
            switch(tst){
                case 0:
                    affiche_paneaux_centre(longueur, largeur, "vous avez perdu");
                    break;
                case -1:
                    affiche_paneaux_centre(longueur, largeur, "vous avez quitter");
                    return ;
                case 1:
                    affiche_paneaux_centre(longueur, largeur, "vous avez gagne");
                    break;
                case 2:
                    affiche_paneaux_centre(longueur, largeur, "vous avez abandonne");
                    break;
            }
            MLV_free_window();
            break;
        case 2:
            niv = NULL;
            lit_fichier(argv[2], &niv);
            if(!joue_test(niv)){
                system("clear");
                fprintf(stderr, "vous avez perdu\n");
            }else{
                system("clear");
                fprintf(stderr, "vous avez gagne\n");
            }
            break;
        default:
            break;
    }
}
