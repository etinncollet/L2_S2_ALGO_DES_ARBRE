/**
 * objet.c
 * Etienne Collet / Lyna Benaibouche
 *
 * commencer le : 4/04/2021
 * fini le : 16/05/2021
 *
 * Projet final Algo des arbre
 * Université Gustave Eiffel
 *
 * permet de gere les different objets
 */
#include "../header/objet.h"


Generation * init_generation(unsigned long inter, unsigned long alu){
    Generation * nouv = NULL;

    nouv = (Generation*)malloc(sizeof(Generation));
    if(nouv == NULL){
        return nouv;
    }
    nouv -> intervalle = inter;
    nouv -> allure_proj = alu;
    return nouv;
}


Deplacement * init_deplac(Direction direc, unsigned long alu){
    Deplacement * nouv = NULL;

    nouv = (Deplacement*)malloc(sizeof(Deplacement));
    if(nouv == NULL){
        return nouv;
    }
    nouv -> direction = direc;
    nouv -> allure = alu;
    return nouv;
}
