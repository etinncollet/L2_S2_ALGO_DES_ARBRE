/**
 * \file moteur.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet de faire fonctionner les niveaux et le projet
 */
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "niveau.h"
#include "temps.h"
#include "objet.h"
#include "affiche.h"
#include "fichier.h"
#include <MLV/MLV_all.h>


/**
 * \fn void utilise_argv(int argc, char **argv)
 * \brief Permet de lire les argument et de les utiliser
 * \param char ** un tableau de chaine de caratere et int le nombre de chaine
 */
void utilise_argv(int argc, char **argv);
