/**
 * \file coordonne.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet de géré les coordonnée
 */
#ifndef __C__
#define __C__

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>


/**
 * \enum Direction
 * Type enumerer qui donne un nom a chaque direction
 */
typedef enum {
  HAUT,
  GAUCHE,
  BAS,
  DROITE
} Direction;


/**
 * \struct Coordonnees
 * \brief Type qui caracterise par x et y les coordonne d'un point dans un plan a deux dimention
 */
typedef struct {
  unsigned int x;
  unsigned int y;
} Coordonnees;


#endif
