/**
 * \file niveau.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet de cree les niveaux du projet
 */
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "coordonne.h"
#include "objet.h"
#include "temps.h"
#include "tas.h"

#ifndef __NI__
#define __NI__

/**
 * \struct Niveau
 * \brief structure qui defini un niveaux
 */
typedef struct {
    /**avec la taille du niveaux*/
    Coordonnees taille;
    /** un tableaux des objet du niveaux*/
    Objet** objets;
    /** les coordonnee du personnage*/
    Coordonnees coo_perso;
    /** l'allure du personnage*/
    unsigned long allure_perso;
    /** le dernier moment ou le personnage a bouger*/
    unsigned long avance;
    /**un boolein qui indique si le personnage peut se deplacer*/
    bool depl_perso_autorise;
} Niveau;


/**
 * Alloue la place memoire pour un niveaux de taille taille
 */
Niveau* malloc_Niveau (Coordonnees taille);


/**
 * Libere la memoire du niveaux en parametre
 */
void free_Niveau (Niveau* niveau);


/**
 * Cree le niveaux 0
 */
Niveau* niveau0();


/**
 * Cree et remplie le tas d'origine d'un niveaux et le renvoie
 */
Tas* construit_Tas(Niveau* niveau);



/**
 * Execute l'evenement e sur le niveaux et rajoute des evenement dans le tas
 */
int traite_evenement(Evenement e, Tas* tas, Niveau* niveau);


/**
 * Affiche un niveaux sur le terminal
 */
void affiche_Niveau (Niveau* niveau);



/**
 * Ajoute un prjectile au fur et a mesur de la partie
 */
void ajoute_projectile(Niveau *niveau, Tas* tas, Evenement e, Direction dir, unsigned long allu);


#endif
