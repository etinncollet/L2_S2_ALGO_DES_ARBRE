/**
 * \file tas.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet de gere les tas
 */
#ifndef __TA__
#define __TA__

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "coordonne.h"
#include "temps.h"


/**
 * \struct Evenement
 * \brief Défini un type evenement
 */
typedef struct {
    /** les coordonnes de l'objet concerner*/
    unsigned long moment;
    /** et le moment de l'evenement*/
    Coordonnees coo_obj;
} Evenement;


/**
 * \struct Tas
 * \brief Définie un tas avec
 */
typedef struct {
    /** Taille du tas */
    unsigned int taille;
    /** Une capaciter maximale */
    unsigned int capacite;
    /** Un tableaux des differente valeurs*/
    Evenement* valeurs;
} Tas;


/**
 * Alloux un tas et l'initialise
 */
Tas* malloc_Tas(unsigned capacite_initiale);


/**
 * Libere la memoire du tas en parametre
 */
void free_Tas(Tas* tas);


/**
 * Teste si l'evenement le plus petit est pres ou non
 */
bool un_evenement_est_pret(Tas* tas);


/* Renvoie et retire de `tas`
 * l'Evenement dont le `moment` est
 * le  plus petit.
 */
int ote_minimum(Tas* tas, Evenement * min);


/**
 * Ajoute un Evenement
 * a un Tas
 */
int ajoute_evenement(Tas* tas, Evenement n);


/**
 * Affiche au terminal un tas pour le debugage
 */
void affiche_Tas(Tas* tas);


#endif
