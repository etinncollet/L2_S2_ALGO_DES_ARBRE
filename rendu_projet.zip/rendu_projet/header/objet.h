/**
 * \file objet.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet de gere les different objets
 */
#ifndef __O__
#define __O__

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "temps.h"
#include "coordonne.h"


/**
 * \enum TypeObjet
 * Type enumerer qui donne un nom a chaque éléments possible
 */
typedef enum {
  VIDE = 0,
  PERSONNAGE,
  DESTINATION,
  MUR,
  LANCEUR,
  PROJECTILE
} TypeObjet;


/**
 * \struct Objet
 * \brief Définie un objet du decord et lui ratache possiblement des donnée complementaire
 */
typedef struct {
    /**
     * Type de l'objet
     */
    TypeObjet type;
    /** Donnee supplementaire: son type depend de
    * `type` ci-dessus:
    * - Deplacement*  si  type == PROJECTILE
    * - Generation* si type == LANCEUR
    * - donnee\_suppl vaut NULL pour les
    *   autres types.
    */
    void* donnee_suppl;
} Objet;


/**
 * \struct Generation
 * \brief Définie l'intervalle de la generation et l'allure des objet generé
 */
typedef struct {
    /** Intervalle entre deux envois de projectiles */
    unsigned long intervalle;
    /** Allure des projectiles envoyes */
    unsigned long allure_proj;
} Generation;


/**
 * \struct Deplacement
 * \brief Définie l'allure des objet concerner et leur direction
 */
typedef struct {
    /** Direction du deplacement */
    Direction direction;
    /** Allure du deplacement */
    unsigned long allure;
} Deplacement;


/**
 * Cree ,initialise et renvoie un type generation d'un lenceur en fonction
 * de l'intervale de l'encement des projectile
 * et l'allure de projectile qu'il lance
 */
Generation * init_generation(unsigned long inter, unsigned long alu);


/**
 * Cree ,initialise et renvoie un type direction d'un projectile
 * avec la direction du projectile et son allure
 */
Deplacement * init_deplac(Direction direc, unsigned long alu);

#endif
