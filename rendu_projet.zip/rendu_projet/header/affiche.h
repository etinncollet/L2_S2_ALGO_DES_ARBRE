/**
 * \file affiche.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet de géré l'affichage
 */
#ifndef __A__
#define __A__

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <MLV/MLV_all.h>
#include "niveau.h"

/**
 * \def TMOTS
 * Taille max des mots des fonction
 */
#define TMOTS 20
/**
 * \def DEBUTX
 * Abscisse du debut de la grille de jeu
 */
#define DEBUTX 50
/**
 * \def DEBUTY
 * Ordonnée du debut de la grille de jeu
 */
#define DEBUTY 100





/**
 * Prend deux entier et renvoie le plus grand des deux
 */
int mini(int un, int deux);


/**
 * Affiche dans le terminal les differents usage du programe
 */
void affiche_usage();


/**
 * Ouvre une fenetre graphique
 */
void ouvre_fenettre(unsigned int *longueur, unsigned int *largeur);


/**
 * Affiche le menu du jeu dans l'aplication graphique
 */
void affiche_menu(char nom[][TMOTS], int nombre);


/**
 * Affiche graphiquement un niveaux
 */
void affiche_graph_niv(unsigned int longueur, unsigned int largeur, Niveau niv, int grille);

/** 
 * Affiche la barre latterale de l'affichage graphique 
 */
void affiche_bare_latterale(unsigned int longueur, unsigned int largeur, unsigned int choix);

/** 
 * Affiche le choix de la taille de chaque niveau graphiquement
 */
void affiche_choix_taille(unsigned int longueur, unsigned int largeur, int choix);

/**
 * Affiche le choix d'un fichier pour un niveu deja concu dedans graphiquement
 */
void affiche_choix_fichier(unsigned int longueur, unsigned int largeur, int choix);


/**
 * Permet de faire une case pour choissire un mot
 * x, y sont les coordonnée en haut a gauche
 */
void affiche_choix_txt(int x, int y, char txt[]);


/**
 * Permet de faire une case pour choissire un nombre
 * x, y sont les coordonnée en haut a gauche
 */
void affiche_choix_nombre(int x, int y, int nombre);

/**
 * Affiche le choix niveau des niveau deja existant dans histoire graphiquement
 */
void affiche_niveau_hist(unsigned int longueur, unsigned int largeur, int choix);


/**
 * Affiche un texte dans une boite au millieux de l'ecran
 */
void affiche_paneaux_centre(unsigned int longueur, unsigned int largeur, char *texte);


/**
 * Affiche la validation pour quitter le jeux
 */
void affiche_exit(unsigned int longueur, unsigned int largeur, int *x, int *y, char *texte);


#endif
