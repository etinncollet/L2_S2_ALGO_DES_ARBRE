/**
 * \file fichier.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet d'ouvrir les different type de fichier
 */
#ifndef __FI__
#define __FI__

#include "niveau.h"
#include <dirent.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>



/**
 * \fn int taille_chaine(char *chaine)
 * \brief Fonction qui renvoie la taille d'une chaine passé en parametre
 * \param char
 * \return int (la taille)
 */
int taille_chaine(char *chaine);


/**
 * \fn int fichier_niveaux(char ***nom, int *nombre)
 * \brief Fonction qui renvoie en parametre une liste de nom de fichier et leur nombre
 * \param char*** , int*
 * \return 1 si tout ce passe bien, 0 sinon
 */
int fichier_niveaux(char ***nom, int *nombre);


/**
 * \brief Fonction qui traduit un fichier de niveau pour pouvoir l'afficher graphiquement
 * \return 1 si tout ce passe bien, 0 sinon
 */
int note_dans_f(Niveau niv, int taille, char *nom);


/**
 * \brief Fonction pour lire un fichier
 * \return 0 si ca marche pas, 1 sinon
 */
int lit_fichier(char *nom, Niveau **niv);


/**
 * \brief Fonction qui recopie une chaine
 * \return longueur de chaine
 */
int recopie_chaine(char *dest, char*base, int i);


/**
 * \brief libere la liste des nombre nom de fichier
 */
void free_lst(char **nom_fichier, int nombre);


#endif
