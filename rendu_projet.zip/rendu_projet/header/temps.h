/**
 * \file temps.h
 * \author Etienne Collet / Lyna Benaibouche
 *
 * \date 4/04/2021 - 16/05/2021
 *
 * \brief Projet final Algo des arbre
 *  Université Gustave Eiffel
 *
 * Permet de gere le temps
 */
#ifndef __TE__
#define __TE__

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/select.h>
#include <time.h>

/**
 * \def une_seconde
 * une variable globale qui donne le nombre de tics qui correspond a une seconde
 */
static const long unsigned une_seconde = CLOCKS_PER_SEC;


/**
 * \def une_milliseconde
 * une variable globale qui donne le nombre de tics qui correspond a une milliseconde
 */
static const long unsigned une_milliseconde = une_seconde/1000;

/**
 * La fonction `maintenant()` renvoie le nombre de "tick" du
 * processeur depuis le lancement du programme.
 */
long unsigned maintenant();


/**
 * La fonction `millisleep(i)` fait en sorte que le programme
 * attende i millisecondes avant de continuer a s'executer.
 */
void millisleep(unsigned long i);

#endif
